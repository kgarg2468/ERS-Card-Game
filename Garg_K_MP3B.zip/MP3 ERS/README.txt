
AUTHOR INFO
Full name: Krish Garg 
Student ID: 2468721
Chapman Email: kgarg@chapman.edu 
Course number and section: CPSC-231-03
Assignment or exercise number: MP 3: ERS Game 

ERRORS:
This assignment was quite confusing at first since it was super long. I previously
hadn't worked on a Java this big from scratch. It was really cool to see all the things
we learned in class work in the final product. My biggest issue was
a loop where the game wouldn't stop. After awhile I realized that the nextPlayer method
was not handling players with no cards left correctly. I first tried to move the first player
from the list to the end which is why the error occurred, although I probably could've figured
out how to solve that problem, I switched to finding the player's index in the list. 

SOURCES
I referenced the class participation activies a lot as they were very useful when
I forgot some logic or how to create a certian method. I also looked at w3schools for
some help with method syntax and to see more examples. 
>https://www.w3schools.com/java/ 